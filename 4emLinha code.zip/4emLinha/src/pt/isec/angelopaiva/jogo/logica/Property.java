package pt.isec.angelopaiva.jogo.logica;

public enum Property {
    PROPERTY_GENERAL,
    PROPERTY_GAME,
    PROPERTY_MINIGAME,
    PROPERTY_REPLAY
}
