package pt.isec.angelopaiva.jogo.logica;

public enum JogoStates {
    VICTORY_P1,
    VICTORY_P2,
    DRAW,
    UNFINISHED
}
