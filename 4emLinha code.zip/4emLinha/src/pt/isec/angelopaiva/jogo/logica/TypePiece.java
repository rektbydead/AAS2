package pt.isec.angelopaiva.jogo.logica;

public enum TypePiece {
    PIECE_P1,
    PIECE_P2,
    NONE
}
