package pt.isec.angelopaiva.jogo.iu.gui.resources.styles;

public class ProjectStyles {
    public static final String STYLES = "styles.css";

    private ProjectStyles() {}
}
