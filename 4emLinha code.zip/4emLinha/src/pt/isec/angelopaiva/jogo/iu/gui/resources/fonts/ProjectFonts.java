package pt.isec.angelopaiva.jogo.iu.gui.resources.fonts;

public class ProjectFonts {
    public static final String FIRA_CODE = "FiraCode-Regular.ttf";
    public static final String ABRIL_TEXT = "AbrilText-Regular.ttf";

    private ProjectFonts() {}
}
