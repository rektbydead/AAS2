package pt.isec.angelopaiva.jogo.iu.gui.resources.images;

public class ProjectImages {
    public static final String ICON = "icon.png";
    public static final String TROPHY = "trophy.png";

    private ProjectImages() {}
}
